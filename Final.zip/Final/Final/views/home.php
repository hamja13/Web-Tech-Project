<html>
<head>
    <title>Document</title>
</head>
<body>
    <center>
        <?php include_once 'header.php'; ?>
        <h1>Welcome to Car Rental Management System</h1>
    </center>
    <link rel="stylesheet" type="text/css" href="CSS/home.css">

</body>
</html>