<html>
<head>
    <title>Document</title>
</head>
<body>
    <center>
        <?php 
         include_once 'admin-header.php' 
        ?>
    </center>
</body>
</html>