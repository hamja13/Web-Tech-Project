<html>
<head>

    <title>Document</title>
</head>
<body>
    <center>
        <h1>Car Rental Management System</h1>
        <h2>
            <a href="home.php">Home</a>|
            <a href="login.php">Login</a>|
            <a href="signup.php">Signup</a>
        </h2>
    </center>
</body>
</html>